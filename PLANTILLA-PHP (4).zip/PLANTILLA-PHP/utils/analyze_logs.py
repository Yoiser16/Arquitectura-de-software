import json
import pandas as pd
import matplotlib.pyplot as plt
from statistics import mean

def analyze_performance():
    with open("performance_log.json") as f:
        data = json.load(f)
    
    df = pd.DataFrame(data)
    
    # Métricas clave
    avg_frame_time = mean(df["frame_time_ms"])
    max_cpu = df["cpu_usage"].max()
    max_ram = df["ram_usage_mb"].max()
    
    print(f"📊 Resultados de la prueba:")
    print(f"- Tiempo promedio por frame: {avg_frame_time:.1f} ms")
    print(f"- Máximo uso de CPU: {max_cpu}%")
    print(f"- Máximo uso de RAM: {max_ram:.1f} MB")
    
    # Gráficos
    plt.figure(figsize=(12, 4))
    
    plt.subplot(131)
    plt.plot(df["timestamp"], df["frame_time_ms"])
    plt.title("Tiempo por Frame (ms)")
    
    plt.subplot(132)
    plt.plot(df["timestamp"], df["cpu_usage"])
    plt.title("Uso de CPU (%)")
    
    plt.subplot(133)
    plt.plot(df["timestamp"], df["ram_usage_mb"])
    plt.title("Uso de RAM (MB)")
    
    plt.tight_layout()
    plt.savefig("performance_metrics.png")
    plt.show()

if __name__ == "__main__":
    analyze_performance()