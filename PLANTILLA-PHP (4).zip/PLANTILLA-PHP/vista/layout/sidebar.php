<nav class="side-menu">
            
            <ul class="side-menu-list p-0">


                <li class="red">
                    <a href="usuario.php" class="activo">
                        <img src="../public/img-inicio/icons8-usuarios-48.png" class="img-inicio" alt="">
                        <!-- <i class="fas fa-house-user"></i> -->
                        <span class="lbl">USUARIOS</span>
                    </a>
                </li>



                <li class="red">
                    <a href="ejecutar_juego.php" class="activo">
                        <img src="../public/img-inicio/arduino.png" class="img-inicio" alt="">
                        <!-- <i class="fas fa-exclamation"></i> -->
                        <span class="lbl">JUEGOS</span>
                    </a>
                </li>



            </ul>
        </nav>