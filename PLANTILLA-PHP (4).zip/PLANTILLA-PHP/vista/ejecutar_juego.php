<?php
echo "<h2>Ejecutando el juego...</h2>";

// Ruta absoluta al .bat
$bat = "C:\\xampp\\htdocs\\PLANTILLA-PHP\\ejecutar_juego.bat";

// Ejecuta el BAT como proceso independiente
shell_exec("start C:\\xampp\\htdocs\\PLANTILLA-PHP\\ejecutar_juego.bat");
?>
