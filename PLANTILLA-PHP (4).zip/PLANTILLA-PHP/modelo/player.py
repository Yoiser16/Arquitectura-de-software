import pygame
from modelo.settings import *
from pygame import gfxdraw

class Player:
    def __init__(self):
        self.rect = pygame.Rect(WIDTH // 2, HEIGHT // 2, PLAYER_SIZE, PLAYER_SIZE)
        self.color = GREEN
        self.base_speed = PLAYER_SPEED
        self.speed = self.base_speed
        self.score = 0
        self.max_health = 100
        self.health = self.max_health
        self.damage_timer = 0
        self.hit_animation = 0
        self.active_powerups = {}
        
    def move(self, keys):
        if keys[pygame.K_LEFT] and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT] and self.rect.right < WIDTH:
            self.rect.x += self.speed
        if keys[pygame.K_UP] and self.rect.top > 0:
            self.rect.y -= self.speed
        if keys[pygame.K_DOWN] and self.rect.bottom < HEIGHT:
            self.rect.y += self.speed
            
    def draw(self, screen):
        # Efecto de golpe (agrandamiento)
        if self.hit_animation > 0:
            size = PLAYER_SIZE + int(5 * (self.hit_animation / 10))
            pygame.gfxdraw.filled_circle(
                screen, 
                self.rect.centerx, 
                self.rect.centery, 
                size // 2, 
                (min(255, self.color[0] + 100), self.color[1], self.color[2])
            )
            self.hit_animation -= 1
        
        # Dibujar jugador
        color = self.color
        if "shield" in self.active_powerups:
            color = CYAN
        pygame.gfxdraw.filled_circle(
            screen, 
            self.rect.centerx, 
            self.rect.centery, 
            PLAYER_SIZE // 2, 
            color
        )
            
    def take_damage(self, amount):
        if "shield" in self.active_powerups or self.damage_timer > 0:
            return False
            
        self.health -= amount
        self.damage_timer = 30  # 0.5 segundos de invulnerabilidad
        self.hit_animation = 10  # Inicia animación de golpe
        return True
        
    def add_powerup(self, powerup_type):
        if powerup_type == "health":
            self.health = min(self.max_health, self.health + self.max_health // 2)
        elif powerup_type == "speed_boost":
            self.active_powerups["speed_boost"] = POWERUP_DURATIONS["speed_boost"]
            self.speed = self.base_speed * 1.15
        elif powerup_type == "shield":
            self.active_powerups["shield"] = POWERUP_DURATIONS["shield"]
        
    def update(self):
        # Actualizar temporizadores
        if self.damage_timer > 0:
            self.damage_timer -= 1
            self.color = (100, 255, 100)  # Color más claro cuando es invulnerable
        else:
            self.color = GREEN
            
        # Actualizar power-ups
        for powerup in list(self.active_powerups.keys()):
            if isinstance(self.active_powerups[powerup], int):
                self.active_powerups[powerup] -= 1
                if self.active_powerups[powerup] <= 0:
                    if powerup == "speed_boost":
                        self.speed = self.base_speed
                    del self.active_powerups[powerup]
        
        # Incrementar puntaje con el tiempo
        self.score += 0.1