import pygame
import random
import math
from modelo.settings import *

class Enemy:
    def __init__(self, player_rect, difficulty_level="medium"):
        self.rect = pygame.Rect(
            random.choice([-ENEMY_SIZE, WIDTH]),
            random.choice([-ENEMY_SIZE, HEIGHT]),
            ENEMY_SIZE, ENEMY_SIZE
        )
        self.color = RED
        self.speed = ENEMY_SPEEDS[difficulty_level] * random.uniform(0.9, 1.1)
        self.player_rect = player_rect

    def update(self, difficulty_factor):
        # Movimiento adaptativo con física de persecución
        dx = self.player_rect.centerx - self.rect.centerx
        dy = self.player_rect.centery - self.rect.centery
        dist = max(1, math.sqrt(dx**2 + dy**2))
        
        # Ajuste de velocidad basado en dificultad
        speed = self.speed * (0.8 + difficulty_factor * 0.4)
        self.rect.x += int(speed * dx / dist)
        self.rect.y += int(speed * dy / dist)

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, self.rect)