import pygame
import random
from modelo.settings import *
from pygame import gfxdraw

class PowerUp:
    TYPES = {
        "shield": BLUE,
        "health": GREEN,
        "speed_boost": YELLOW
    }
    
    def __init__(self):
        self.type = random.choice(list(self.TYPES.keys()))
        self.rect = pygame.Rect(
            random.randint(POWERUP_SIZE, WIDTH - POWERUP_SIZE),
            random.randint(POWERUP_SIZE, HEIGHT - POWERUP_SIZE),
            POWERUP_SIZE, POWERUP_SIZE
        )
        self.color = self.TYPES[self.type]
        self.active = True
        
    def draw(self, screen):
        if not self.active:
            return
            
        # Dibujar power-up con forma de diamante
        points = [
            (self.rect.centerx, self.rect.top),
            (self.rect.right, self.rect.centery),
            (self.rect.centerx, self.rect.bottom),
            (self.rect.left, self.rect.centery)
        ]
        pygame.draw.polygon(screen, self.color, points)
        pygame.draw.polygon(screen, WHITE, points, 2)
        
    def check_collision(self, player_rect):
        if not self.active:
            return False
        return self.rect.colliderect(player_rect)