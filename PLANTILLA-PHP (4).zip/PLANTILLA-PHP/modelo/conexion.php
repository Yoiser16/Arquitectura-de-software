<?php
$conexion=new mysqli("localhost","root","","wastech", 3307);
$conexion->set_charset("utf8");
date_default_timezone_set("America/Bogota");
?>