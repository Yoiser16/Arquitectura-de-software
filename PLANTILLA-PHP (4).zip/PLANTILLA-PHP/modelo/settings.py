# Configuraciones del juego
WIDTH, HEIGHT = 800, 600
FPS = 60
TITLE = "Yofe Dodge"

# Colores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
GRAY = (100, 100, 100)
LIGHT_GRAY = (200, 200, 200)
YELLOW = (255, 255, 0)
CYAN = (0, 255, 255)

# Configuración del jugador
PLAYER_SPEED = 5
PLAYER_SIZE = 20

# Configuración de enemigos
ENEMY_SIZE = 15
SPAWN_RATES = {
    "easy": 90,
    "medium": 60,
    "hard": 30
}
ENEMY_SPEEDS = {
    "easy": 1.5,
    "medium": 2.5,
    "hard": 3.5
}
MIN_DISTANCE_BETWEEN_ENEMIES = 50  # Distancia mínima entre enemigos

# Configuración de power-ups
POWERUP_SIZE = 20
POWERUP_SPAWN_RATE = 500  # frames
POWERUP_DURATIONS = {
    "shield": 4 * FPS,
    "health": 0,
    "speed_boost": 5 * FPS
}