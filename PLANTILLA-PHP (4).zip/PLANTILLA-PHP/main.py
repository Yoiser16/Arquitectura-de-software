import pygame
from controlador.game import Game

if __name__ == "__main__":
    try:
        pygame.init()  # Inicializar pygame si es necesario
        game = Game()
        game.run()
    except Exception as e:
        print(f"Error al ejecutar el juego: {str(e)}")
        input("Presiona Enter para salir...")