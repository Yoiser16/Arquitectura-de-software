import pygame
import sys
import math
from modelo.player import Player
from modelo.enemy import Enemy
from modelo.powerup import PowerUp
from modelo.settings import *
import random

class Button:
    def __init__(self, x, y, width, height, text, color=LIGHT_GRAY, hover_color=WHITE, text_color=BLACK):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.color = color
        self.hover_color = hover_color
        self.text_color = text_color
        self.is_hovered = False
        self.font = pygame.font.SysFont(None, 36)

    def draw(self, screen):
        color = self.hover_color if self.is_hovered else self.color
        pygame.draw.rect(screen, color, self.rect, border_radius=10)
        pygame.draw.rect(screen, WHITE, self.rect, 2, border_radius=10)

        text_surface = self.font.render(self.text, True, self.text_color)
        text_rect = text_surface.get_rect(center=self.rect.center)
        screen.blit(text_surface, text_rect)

    def check_hover(self, pos):
        self.is_hovered = self.rect.collidepoint(pos)
        return self.is_hovered

    def is_clicked(self, pos, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            return self.rect.collidepoint(pos)
        return False

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption(TITLE)
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont(None, 48)
        self.small_font = pygame.font.SysFont(None, 36)

        self.state = "main_menu"
        self.difficulty = "medium"
        self.difficulty_level = 1.0
        self.adaptive_timer = 0

        self.player = None
        self.enemies = []
        self.powerups = []
        self.spawn_timer = 0
        self.powerup_timer = 0

        self.create_buttons()

    def create_buttons(self):
        self.start_button = Button(WIDTH//2 - 100, HEIGHT//2 + 50, 200, 50, "Iniciar Juego")
        self.easy_button = Button(WIDTH//2 - 100, HEIGHT//2 - 60, 200, 50, "Fácil", GREEN)
        self.medium_button = Button(WIDTH//2 - 100, HEIGHT//2, 200, 50, "Medio", BLUE)
        self.hard_button = Button(WIDTH//2 - 100, HEIGHT//2 + 60, 200, 50, "Difícil", RED)
        self.restart_button = Button(WIDTH//2 - 100, HEIGHT//2 + 30, 200, 50, "Jugar de nuevo")
        self.resume_button = Button(WIDTH//2 - 100, HEIGHT//2 - 90, 200, 50, "Reanudar")
        self.restart_pause_button = Button(WIDTH//2 - 100, HEIGHT//2 - 30, 200, 50, "Reiniciar")
        self.quit_button = Button(WIDTH//2 - 100, HEIGHT//2 + 30, 200, 50, "Salir al menú")

    def start_game(self):
        self.player = Player()
        self.player.game = self
        self.enemies = []
        self.powerups = []
        self.spawn_timer = 0
        self.powerup_timer = 0
        self.state = "playing"
        self.adaptive_timer = 0

        if self.difficulty == "easy":
            base_score = random.randint(0, 50)
        elif self.difficulty == "medium":
            base_score = random.randint(51, 100)
        elif self.difficulty == "hard":
            base_score = random.randint(101, 150)
        else:
            base_score = 50

        self.player.score = base_score
        self.difficulty_level = 1.0 + base_score / 100

    def spawn_enemies(self):
        self.spawn_timer += 1
        if self.spawn_timer >= SPAWN_RATES[self.difficulty]:
            self.enemies.append(Enemy(self.player.rect, self.difficulty))
            self.spawn_timer = 0

    def spawn_powerups(self):
        self.powerup_timer += 1
        if self.powerup_timer >= POWERUP_SPAWN_RATE and len(self.powerups) < 3:
            self.powerups.append(PowerUp())
            self.powerup_timer = 0

    def handle_collisions(self):
        for enemy in self.enemies[:]:
            if self.player.rect.colliderect(enemy.rect):
                if self.player.take_damage(10):
                    dx = self.player.rect.centerx - enemy.rect.centerx
                    dy = self.player.rect.centery - enemy.rect.centery
                    dist = max(1, math.sqrt(dx**2 + dy**2))
                    bounce_force = 15
                    self.player.rect.x += int(bounce_force * dx / dist)
                    self.player.rect.y += int(bounce_force * dy / dist)
                    enemy.rect.x -= int(bounce_force * dx / dist)
                    enemy.rect.y -= int(bounce_force * dy / dist)
                    for entity in [self.player, enemy]:
                        entity.rect.x = max(0, min(WIDTH - entity.rect.width, entity.rect.x))
                        entity.rect.y = max(0, min(HEIGHT - entity.rect.height, entity.rect.y))
        for powerup in self.powerups[:]:
            if powerup.check_collision(self.player.rect):
                self.player.add_powerup(powerup.type)
                self.powerups.remove(powerup)

    def adjust_difficulty(self):
        self.adaptive_timer += 1
        if self.adaptive_timer >= FPS:
            self.adaptive_timer = 0
            score_factor = self.player.score / 400
            health_factor = (self.player.max_health - self.player.health) / (2 * self.player.max_health)
            new_level = 1.0 + score_factor - health_factor
            self.difficulty_level = max(0.5, min(new_level, 5.0))

    def draw_health_bar(self, screen):
        bar_width = 200
        bar_height = 15
        health_ratio = self.player.health / self.player.max_health
        pygame.draw.rect(screen, RED, (10, 10, bar_width, bar_height), border_radius=5)
        pygame.draw.rect(screen, GREEN, (10, 10, bar_width * health_ratio, bar_height), border_radius=5)
        pygame.draw.rect(screen, WHITE, (10, 10, bar_width, bar_height), 2, border_radius=5)

    def draw_main_menu(self):
        self.screen.fill(BLACK)
        title = self.font.render("Yofe Dodge", True, GREEN)
        title_rect = title.get_rect(center=(WIDTH//2, HEIGHT//2 - 100))
        self.screen.blit(title, title_rect)
        self.start_button.draw(self.screen)
        pygame.display.flip()

    def draw_difficulty_select(self):
        self.screen.fill(BLACK)
        title = self.font.render("Selecciona Dificultad", True, WHITE)
        title_rect = title.get_rect(center=(WIDTH//2, HEIGHT//2 - 150))
        self.screen.blit(title, title_rect)
        self.easy_button.draw(self.screen)
        self.medium_button.draw(self.screen)
        self.hard_button.draw(self.screen)
        pygame.display.flip()

    def draw_playing(self):
        self.screen.fill(BLACK)
        for powerup in self.powerups:
            powerup.draw(self.screen)
        for enemy in self.enemies:
            enemy.draw(self.screen)
        self.player.draw(self.screen)
        self.draw_health_bar(self.screen)
        score_text = self.small_font.render(f"Puntaje: {int(self.player.score)}", True, WHITE)
        diff_text = self.small_font.render(f"Dificultad: {self.difficulty.capitalize()} ({self.difficulty_level:.2f}x)", True, WHITE)
        self.screen.blit(score_text, (10, 35))
        self.screen.blit(diff_text, (10, 70))
        y_offset = 110
        for powerup, duration in self.player.active_powerups.items():
            if isinstance(duration, int) and duration > 0:
                text = self.small_font.render(
                    f"{powerup.replace('_', ' ').title()}: {duration//FPS}s",
                    True,
                    YELLOW
                )
                self.screen.blit(text, (10, y_offset))
                y_offset += 30
        pygame.display.flip()

    def draw_game_over(self):
        self.screen.fill(BLACK)
        title = self.font.render("Game Over", True, RED)
        title_rect = title.get_rect(center=(WIDTH//2, HEIGHT//2 - 100))
        self.screen.blit(title, title_rect)
        score_text = self.small_font.render(f"Puntaje final: {int(self.player.score)}", True, WHITE)
        score_rect = score_text.get_rect(center=(WIDTH//2, HEIGHT//2 - 30))
        self.screen.blit(score_text, score_rect)
        self.restart_button.draw(self.screen)
        pygame.display.flip()

    def draw_paused(self):
        s = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        s.fill((0, 0, 0, 180))
        self.screen.blit(s, (0, 0))
        title = self.font.render("Juego Pausado", True, WHITE)
        title_rect = title.get_rect(center=(WIDTH//2, HEIGHT//2 - 150))
        self.screen.blit(title, title_rect)
        self.resume_button.draw(self.screen)
        self.restart_pause_button.draw(self.screen)
        self.quit_button.draw(self.screen)
        pygame.display.flip()

    def handle_events(self):
        mouse_pos = pygame.mouse.get_pos()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    if self.state == "playing":
                        self.state = "paused"
                    elif self.state == "paused":
                        self.state = "playing"
            if event.type == pygame.MOUSEMOTION:
                if self.state == "main_menu":
                    self.start_button.check_hover(mouse_pos)
                elif self.state == "difficulty_select":
                    self.easy_button.check_hover(mouse_pos)
                    self.medium_button.check_hover(mouse_pos)
                    self.hard_button.check_hover(mouse_pos)
                elif self.state == "game_over":
                    self.restart_button.check_hover(mouse_pos)
                elif self.state == "paused":
                    self.resume_button.check_hover(mouse_pos)
                    self.restart_pause_button.check_hover(mouse_pos)
                    self.quit_button.check_hover(mouse_pos)
            if event.type == pygame.MOUSEBUTTONDOWN:
                if self.state == "main_menu" and self.start_button.is_clicked(mouse_pos, event):
                    self.state = "difficulty_select"
                elif self.state == "difficulty_select":
                    if self.easy_button.is_clicked(mouse_pos, event):
                        self.difficulty = "easy"
                        self.start_game()
                    elif self.medium_button.is_clicked(mouse_pos, event):
                        self.difficulty = "medium"
                        self.start_game()
                    elif self.hard_button.is_clicked(mouse_pos, event):
                        self.difficulty = "hard"
                        self.start_game()
                elif self.state == "game_over" and self.restart_button.is_clicked(mouse_pos, event):
                    self.state = "difficulty_select"
                elif self.state == "paused":
                    if self.resume_button.is_clicked(mouse_pos, event):
                        self.state = "playing"
                    elif self.restart_pause_button.is_clicked(mouse_pos, event):
                        self.start_game()
                    elif self.quit_button.is_clicked(mouse_pos, event):
                        self.state = "difficulty_select"

    def update(self):
        if self.state == "playing":
            keys = pygame.key.get_pressed()
            self.player.move(keys)
            self.player.update()
            self.spawn_enemies()
            self.spawn_powerups()
            for enemy in self.enemies:
                enemy.update(self.difficulty_level)
            self.handle_collisions()
            self.adjust_difficulty()
            if self.player.health <= 0:
                self.state = "game_over"

    def draw(self):
        if self.state == "main_menu":
            self.draw_main_menu()
        elif self.state == "difficulty_select":
            self.draw_difficulty_select()
        elif self.state == "playing":
            self.draw_playing()
        elif self.state == "game_over":
            self.draw_game_over()
        elif self.state == "paused":
            self.draw_playing()
            self.draw_paused()

    def run(self):
        while True:
            self.clock.tick(FPS)
            self.handle_events()
            self.update()
            self.draw()

if __name__ == "__main__":
    game = Game()
    game.run()
